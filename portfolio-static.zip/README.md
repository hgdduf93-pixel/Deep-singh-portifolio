# Deep Singh — Portfolio (Static Distribution)

This package contains the fully static build of the portfolio for **Deep Singh** (Android App Developer • Vibe Coder).

## How to Host on Cloudflare Pages (Direct Upload)
1. Log in to [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. Navigate to **Workers & Pages** -> **Create application** -> **Pages** -> **Upload assets**
3. Drag & drop this folder (or the `portfolio-static.zip` unzipped)
4. Your site is live immediately without needing any build commands or node dependencies!

## Included Files
- `index.html` - Semantic, high-performance HTML5 document
- `styles.css` - Full typography & styles
- `app.js` - Lightweight vanilla interactions
- `assets/` - Videos, screenshots, and visual media
- `favicon.svg` & `robots.txt`
